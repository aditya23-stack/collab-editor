import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import DocumentSidebar from "@/components/DocumentSidebar";
import EditorToolbar from "@/components/EditorToolbar";
import CollaborativeEditor from "@/components/CollaborativeEditor";
import NewDocumentDialog from "@/components/NewDocumentDialog";
import DeleteConfirmDialog from "@/components/DeleteConfirmDialog";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";

interface Document {
  id: string;
  title: string;
  content: string;
  updatedAt: string;
}

interface User {
  id: string;
  name: string;
  color: string;
}

const colors = [
  "hsl(217, 91%, 60%)",
  "hsl(142, 76%, 36%)",
  "hsl(262, 83%, 58%)",
  "hsl(38, 92%, 50%)",
  "hsl(340, 82%, 52%)",
];

const currentUser = {
  id: String(Date.now()),
  name: "You",
  color: colors[0],
};

export default function Home() {
  const { toast } = useToast();
  const [activeDocumentId, setActiveDocumentId] = useState<string | null>(null);
  const [newDialogOpen, setNewDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<"saved" | "saving" | "unsaved">("saved");
  const [localContent, setLocalContent] = useState<string>("");
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const { data: documents = [], isLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });

  const { data: activeDocument } = useQuery<Document>({
    queryKey: ["/api/documents", activeDocumentId],
    enabled: !!activeDocumentId,
  });

  const { activeUsers, sendContentChange } = useWebSocket({
    documentId: activeDocumentId || "",
    userId: currentUser.id,
    userName: currentUser.name,
    userColor: currentUser.color,
    onContentUpdate: (content, userId) => {
      if (userId !== currentUser.id && activeDocumentId) {
        setLocalContent(content);
        queryClient.invalidateQueries({ queryKey: ["/api/documents", activeDocumentId] });
      }
    },
  });

  useEffect(() => {
    if (activeDocument) {
      setLocalContent(activeDocument.content);
    }
  }, [activeDocument?.id]);

  useEffect(() => {
    if (documents.length > 0 && !activeDocumentId) {
      setActiveDocumentId(documents[0].id);
    }
  }, [documents, activeDocumentId]);

  // Clear pending saves when switching documents
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
        saveTimeoutRef.current = null;
      }
    };
  }, [activeDocumentId]);

  const createDocumentMutation = useMutation({
    mutationFn: async (data: { title: string; content: string }) => {
      const res = await apiRequest("POST", "/api/documents", data);
      return await res.json();
    },
    onSuccess: (newDoc: Document) => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      setActiveDocumentId(newDoc.id);
      toast({
        title: "Document created",
        description: "Your new document has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateDocumentMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Document> }) => {
      const res = await apiRequest("PATCH", `/api/documents/${id}`, updates);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/documents", activeDocumentId] });
      setSaveStatus("saved");
    },
    onError: () => {
      setSaveStatus("unsaved");
      toast({
        title: "Failed to save",
        description: "Your changes could not be saved. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteDocumentMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "Document deleted",
        description: "The document has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleContentChange = useCallback((content: string) => {
    if (!activeDocumentId) return;

    setLocalContent(content);
    setSaveStatus("saving");
    
    // Broadcast via WebSocket for real-time updates
    sendContentChange(content);

    // Clear previous timeout
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    // Debounced save to database via REST API
    saveTimeoutRef.current = setTimeout(() => {
      updateDocumentMutation.mutate({
        id: activeDocumentId,
        updates: { content },
      });
    }, 1000);
  }, [activeDocumentId, sendContentChange, updateDocumentMutation]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, []);

  const handleTitleChange = useCallback((title: string) => {
    if (!activeDocumentId) return;
    
    setSaveStatus("saving");
    updateDocumentMutation.mutate({
      id: activeDocumentId,
      updates: { title },
    });
  }, [activeDocumentId, updateDocumentMutation]);

  const handleNewDocument = () => {
    setNewDialogOpen(true);
  };

  const handleCreateDocument = (title: string) => {
    createDocumentMutation.mutate({
      title,
      content: "",
    });
  };

  const handleDeleteDocument = (id: string) => {
    setDocumentToDelete(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (documentToDelete) {
      deleteDocumentMutation.mutate(documentToDelete);
      if (activeDocumentId === documentToDelete) {
        const remaining = documents.filter((doc) => doc.id !== documentToDelete);
        setActiveDocumentId(remaining[0]?.id || null);
      }
      setDocumentToDelete(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <p className="text-muted-foreground">Loading documents...</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <DocumentSidebar
        documents={documents}
        activeDocumentId={activeDocumentId}
        onDocumentSelect={setActiveDocumentId}
        onNewDocument={handleNewDocument}
        onDeleteDocument={handleDeleteDocument}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        {activeDocument ? (
          <>
            <EditorToolbar
              title={activeDocument.title}
              onTitleChange={handleTitleChange}
              saveStatus={saveStatus}
              activeUsers={activeUsers}
            />
            <CollaborativeEditor
              content={localContent}
              onChange={handleContentChange}
              placeholder="Start typing..."
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-muted-foreground">No document selected</p>
              <p className="text-sm text-muted-foreground mt-1">
                Create a new document to get started
              </p>
            </div>
          </div>
        )}
      </div>

      <NewDocumentDialog
        open={newDialogOpen}
        onOpenChange={setNewDialogOpen}
        onCreateDocument={handleCreateDocument}
      />

      <DeleteConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        documentTitle={
          documents.find((doc) => doc.id === documentToDelete)?.title || ""
        }
      />
    </div>
  );
}
