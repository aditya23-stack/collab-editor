import { useEffect, useRef, useState } from "react";

interface User {
  id: string;
  name: string;
  color: string;
}

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

interface UseWebSocketOptions {
  documentId: string;
  userId: string;
  userName: string;
  userColor: string;
  onContentUpdate?: (content: string, userId: string) => void;
  onUserJoined?: (activeUsers: User[]) => void;
  onUserLeft?: (activeUsers: User[]) => void;
}

export function useWebSocket({
  documentId,
  userId,
  userName,
  userColor,
  onContentUpdate,
  onUserJoined,
  onUserLeft,
}: UseWebSocketOptions) {
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [activeUsers, setActiveUsers] = useState<User[]>([]);

  useEffect(() => {
    // Only connect if we have a valid documentId
    if (!documentId) {
      setIsConnected(false);
      setActiveUsers([]);
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connected");
      setIsConnected(true);
      
      ws.send(JSON.stringify({
        type: "join",
        documentId,
        userId,
        userName,
        userColor,
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);

        switch (message.type) {
          case "joined":
            setActiveUsers(message.activeUsers);
            break;

          case "user-joined":
            setActiveUsers(message.activeUsers);
            onUserJoined?.(message.activeUsers);
            break;

          case "user-left":
            setActiveUsers(message.activeUsers);
            onUserLeft?.(message.activeUsers);
            break;

          case "content-update":
            onContentUpdate?.(message.content, message.userId);
            break;

          default:
            console.log("Unknown WebSocket message:", message);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setIsConnected(false);
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [documentId, userId, userName, userColor]);

  const sendContentChange = (content: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: "content-change",
        documentId,
        content,
      }));
    }
  };

  return {
    isConnected,
    activeUsers,
    sendContentChange,
  };
}
