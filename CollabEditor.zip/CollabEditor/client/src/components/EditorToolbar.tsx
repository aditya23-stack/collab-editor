import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, Loader2, Users } from "lucide-react";
import UserPresence from "./UserPresence";

interface User {
  id: string;
  name: string;
  color: string;
}

interface EditorToolbarProps {
  title: string;
  onTitleChange: (title: string) => void;
  saveStatus: "saved" | "saving" | "unsaved";
  activeUsers: User[];
}

export default function EditorToolbar({
  title,
  onTitleChange,
  saveStatus,
  activeUsers,
}: EditorToolbarProps) {
  return (
    <div className="h-14 border-b border-border bg-background px-6 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <Input
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          placeholder="Untitled Document"
          className="text-lg font-semibold border-0 focus-visible:ring-0 px-0 max-w-md"
          data-testid="input-document-title"
        />
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {saveStatus === "saving" && (
            <>
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>Saving...</span>
            </>
          )}
          {saveStatus === "saved" && (
            <>
              <Check className="w-3 h-3" />
              <span>Saved</span>
            </>
          )}
          {saveStatus === "unsaved" && <span>Unsaved changes</span>}
        </div>

        {activeUsers.length > 0 && (
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <UserPresence users={activeUsers} />
          </div>
        )}
      </div>
    </div>
  );
}
