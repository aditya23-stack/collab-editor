import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, FileText, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Document {
  id: string;
  title: string;
  content: string;
  updatedAt: string | Date;
}

interface DocumentSidebarProps {
  documents: Document[];
  activeDocumentId: string | null;
  onDocumentSelect: (id: string) => void;
  onNewDocument: () => void;
  onDeleteDocument: (id: string) => void;
}

export default function DocumentSidebar({
  documents,
  activeDocumentId,
  onDocumentSelect,
  onNewDocument,
  onDeleteDocument,
}: DocumentSidebarProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col h-screen">
      <div className="p-4 border-b border-sidebar-border">
        <h1 className="text-xl font-semibold text-sidebar-foreground mb-3">CollabEdit</h1>
        <Button
          onClick={onNewDocument}
          className="w-full"
          size="default"
          data-testid="button-new-document"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Document
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2">
          {documents.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <FileText className="w-12 h-12 text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground">No documents yet</p>
              <p className="text-xs text-muted-foreground mt-1">Create one to get started</p>
            </div>
          ) : (
            <div className="space-y-1">
              {documents.map((doc) => (
                <div
                  key={doc.id}
                  className="relative group"
                  onMouseEnter={() => setHoveredId(doc.id)}
                  onMouseLeave={() => setHoveredId(null)}
                >
                  <div className="relative">
                    <button
                      onClick={() => onDocumentSelect(doc.id)}
                      className={`w-full text-left p-3 rounded-md transition-all duration-150 ${
                        activeDocumentId === doc.id
                          ? "bg-sidebar-accent border-l-2 border-l-sidebar-primary"
                          : "hover-elevate"
                      }`}
                      data-testid={`button-document-${doc.id}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-sidebar-foreground truncate">
                            {doc.title || "Untitled"}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatDistanceToNow(new Date(doc.updatedAt), { addSuffix: true })}
                          </p>
                        </div>
                        <div className="w-6" />
                      </div>
                    </button>
                    {hoveredId === doc.id && activeDocumentId !== doc.id && (
                      <div className="absolute top-3 right-3">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteDocument(doc.id);
                          }}
                          data-testid={`button-delete-${doc.id}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
