import { useState, useRef, useEffect } from "react";

interface CollaborativeEditorProps {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
}

export default function CollaborativeEditor({
  content,
  onChange,
  placeholder = "Start typing...",
}: CollaborativeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (editorRef.current && editorRef.current.innerText !== content) {
      editorRef.current.innerText = content;
    }
  }, [content]);

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerText);
    }
  };

  return (
    <div className="h-full overflow-auto">
      <div className="max-w-4xl mx-auto py-12 px-6">
        <div
          ref={editorRef}
          contentEditable
          onInput={handleInput}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          data-placeholder={placeholder}
          className="min-h-[500px] text-base leading-relaxed font-mono outline-none"
          data-testid="editor-content"
        />
      </div>
    </div>
  );
}
