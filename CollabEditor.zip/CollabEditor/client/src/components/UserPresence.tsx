import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface User {
  id: string;
  name: string;
  color: string;
}

interface UserPresenceProps {
  users: User[];
}

const colors = [
  "hsl(217, 91%, 60%)",
  "hsl(142, 76%, 36%)",
  "hsl(262, 83%, 58%)",
  "hsl(38, 92%, 50%)",
  "hsl(340, 82%, 52%)",
  "hsl(199, 89%, 48%)",
  "hsl(291, 64%, 42%)",
  "hsl(24, 100%, 50%)",
];

export default function UserPresence({ users }: UserPresenceProps) {
  const visibleUsers = users.slice(0, 5);
  const remainingCount = users.length - visibleUsers.length;

  if (users.length === 0) {
    return null;
  }

  return (
    <div className="flex items-center gap-1" data-testid="user-presence">
      {visibleUsers.map((user, index) => (
        <Tooltip key={user.id}>
          <TooltipTrigger asChild>
            <Avatar
              className="h-8 w-8 border-2 border-background"
              style={{
                backgroundColor: user.color || colors[index % colors.length],
                marginLeft: index > 0 ? "-8px" : "0",
              }}
            >
              <AvatarFallback className="text-white text-xs font-medium">
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase()
                  .slice(0, 2)}
              </AvatarFallback>
            </Avatar>
          </TooltipTrigger>
          <TooltipContent>
            <p>{user.name}</p>
          </TooltipContent>
        </Tooltip>
      ))}
      {remainingCount > 0 && (
        <Tooltip>
          <TooltipTrigger asChild>
            <Avatar className="h-8 w-8 border-2 border-background bg-muted -ml-2">
              <AvatarFallback className="text-xs font-medium">
                +{remainingCount}
              </AvatarFallback>
            </Avatar>
          </TooltipTrigger>
          <TooltipContent>
            <p>{remainingCount} more user{remainingCount > 1 ? "s" : ""}</p>
          </TooltipContent>
        </Tooltip>
      )}
    </div>
  );
}
