import DocumentSidebar from "../DocumentSidebar";

export default function DocumentSidebarExample() {
  const mockDocuments = [
    {
      id: "1",
      title: "Project Roadmap 2025",
      content: "# Q1 Goals...",
      updatedAt: new Date(Date.now() - 1000 * 60 * 5),
    },
    {
      id: "2",
      title: "Meeting Notes",
      content: "Discussed new features...",
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
    },
    {
      id: "3",
      title: "Untitled",
      content: "",
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
  ];

  return (
    <DocumentSidebar
      documents={mockDocuments}
      activeDocumentId="1"
      onDocumentSelect={(id) => console.log("Selected document:", id)}
      onNewDocument={() => console.log("New document clicked")}
      onDeleteDocument={(id) => console.log("Delete document:", id)}
    />
  );
}
