import { useState } from "react";
import EditorToolbar from "../EditorToolbar";

export default function EditorToolbarExample() {
  const [title, setTitle] = useState("Project Roadmap 2025");

  const mockUsers = [
    { id: "1", name: "Alice Johnson", color: "hsl(217, 91%, 60%)" },
    { id: "2", name: "Bob Smith", color: "hsl(142, 76%, 36%)" },
    { id: "3", name: "Charlie Davis", color: "hsl(262, 83%, 58%)" },
  ];

  return (
    <div className="bg-background">
      <EditorToolbar
        title={title}
        onTitleChange={setTitle}
        saveStatus="saved"
        activeUsers={mockUsers}
      />
    </div>
  );
}
