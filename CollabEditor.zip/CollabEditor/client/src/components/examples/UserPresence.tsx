import UserPresence from "../UserPresence";

export default function UserPresenceExample() {
  const mockUsers = [
    { id: "1", name: "Alice Johnson", color: "hsl(217, 91%, 60%)" },
    { id: "2", name: "Bob Smith", color: "hsl(142, 76%, 36%)" },
    { id: "3", name: "Charlie Davis", color: "hsl(262, 83%, 58%)" },
    { id: "4", name: "Diana Prince", color: "hsl(38, 92%, 50%)" },
    { id: "5", name: "Evan Williams", color: "hsl(340, 82%, 52%)" },
    { id: "6", name: "Fiona Green", color: "hsl(199, 89%, 48%)" },
  ];

  return (
    <div className="p-8 bg-background">
      <UserPresence users={mockUsers} />
    </div>
  );
}
