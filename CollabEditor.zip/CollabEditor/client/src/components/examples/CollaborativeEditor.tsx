import { useState } from "react";
import CollaborativeEditor from "../CollaborativeEditor";

export default function CollaborativeEditorExample() {
  const [content, setContent] = useState(
    "This is a collaborative text editor.\n\nYou can type here and changes will be synchronized in real-time with other users.\n\nTry editing this text!"
  );

  return (
    <div className="h-screen bg-background">
      <CollaborativeEditor
        content={content}
        onChange={(newContent) => {
          setContent(newContent);
          console.log("Content changed:", newContent);
        }}
        placeholder="Start typing your thoughts..."
      />
    </div>
  );
}
