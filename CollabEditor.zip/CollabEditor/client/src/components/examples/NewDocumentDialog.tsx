import { useState } from "react";
import NewDocumentDialog from "../NewDocumentDialog";
import { Button } from "@/components/ui/button";

export default function NewDocumentDialogExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-8 bg-background">
      <Button onClick={() => setOpen(true)}>Open Dialog</Button>
      <NewDocumentDialog
        open={open}
        onOpenChange={setOpen}
        onCreateDocument={(title) => {
          console.log("Creating document:", title);
          setOpen(false);
        }}
      />
    </div>
  );
}
