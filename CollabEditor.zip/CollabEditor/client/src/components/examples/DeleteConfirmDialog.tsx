import { useState } from "react";
import DeleteConfirmDialog from "../DeleteConfirmDialog";
import { Button } from "@/components/ui/button";

export default function DeleteConfirmDialogExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-8 bg-background">
      <Button variant="destructive" onClick={() => setOpen(true)}>
        Delete Document
      </Button>
      <DeleteConfirmDialog
        open={open}
        onOpenChange={setOpen}
        onConfirm={() => {
          console.log("Document deleted");
          setOpen(false);
        }}
        documentTitle="Project Roadmap 2025"
      />
    </div>
  );
}
