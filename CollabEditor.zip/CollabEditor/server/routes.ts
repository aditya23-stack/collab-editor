import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertDocumentSchema } from "@shared/schema";
import { z } from "zod";

interface WSClient extends WebSocket {
  documentId?: string;
  userId?: string;
  userName?: string;
  userColor?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all documents
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getAllDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  // Get a single document
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      console.error("Error fetching document:", error);
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  // Create a new document
  app.post("/api/documents", async (req, res) => {
    try {
      const data = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(data);
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid document data", details: error.errors });
      }
      console.error("Error creating document:", error);
      res.status(500).json({ error: "Failed to create document" });
    }
  });

  // Update a document
  app.patch("/api/documents/:id", async (req, res) => {
    try {
      const updates = insertDocumentSchema.partial().parse(req.body);
      const document = await storage.updateDocument(req.params.id, updates);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid document data", details: error.errors });
      }
      console.error("Error updating document:", error);
      res.status(500).json({ error: "Failed to update document" });
    }
  });

  // Delete a document
  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const success = await storage.deleteDocument(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting document:", error);
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time collaboration
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const clients = new Map<string, Set<WSClient>>();

  wss.on("connection", (ws: WSClient) => {
    console.log("New WebSocket connection");

    ws.on("message", async (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());

        switch (message.type) {
          case "join": {
            const { documentId, userId, userName, userColor } = message;
            ws.documentId = documentId;
            ws.userId = userId;
            ws.userName = userName;
            ws.userColor = userColor;

            if (!clients.has(documentId)) {
              clients.set(documentId, new Set());
            }
            clients.get(documentId)!.add(ws);

            const activeUsers = Array.from(clients.get(documentId) || []).map((client) => ({
              id: client.userId,
              name: client.userName,
              color: client.userColor,
            }));

            broadcast(documentId, {
              type: "user-joined",
              userId,
              userName,
              userColor,
              activeUsers,
            }, ws);

            ws.send(JSON.stringify({
              type: "joined",
              activeUsers,
            }));

            console.log(`User ${userName} joined document ${documentId}`);
            break;
          }

          case "content-change": {
            const { documentId, content } = message;
            
            await storage.updateDocument(documentId, { content });

            broadcast(documentId, {
              type: "content-update",
              content,
              userId: ws.userId,
            }, ws);
            break;
          }

          case "cursor-position": {
            const { documentId, position } = message;
            
            broadcast(documentId, {
              type: "cursor-update",
              userId: ws.userId,
              userName: ws.userName,
              userColor: ws.userColor,
              position,
            }, ws);
            break;
          }

          default:
            console.log("Unknown message type:", message.type);
        }
      } catch (error) {
        console.error("Error handling WebSocket message:", error);
      }
    });

    ws.on("close", () => {
      if (ws.documentId && clients.has(ws.documentId)) {
        clients.get(ws.documentId)!.delete(ws);

        const activeUsers = Array.from(clients.get(ws.documentId) || []).map((client) => ({
          id: client.userId,
          name: client.userName,
          color: client.userColor,
        }));

        broadcast(ws.documentId, {
          type: "user-left",
          userId: ws.userId,
          activeUsers,
        });

        if (clients.get(ws.documentId)!.size === 0) {
          clients.delete(ws.documentId);
        }

        console.log(`User ${ws.userName} left document ${ws.documentId}`);
      }
    });

    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
    });
  });

  function broadcast(documentId: string, message: any, excludeClient?: WSClient) {
    const documentClients = clients.get(documentId);
    if (!documentClients) return;

    const messageStr = JSON.stringify(message);
    documentClients.forEach((client) => {
      if (client !== excludeClient && client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  return httpServer;
}
